import javax.swing.ImageIcon;
import java.io.Serializable;

public class Carta implements Serializable {
    private ImageIcon immagine;
    private String color;
    private int number;
    public Carta(String path){
        String []tmp = path.split("/");
        tmp = tmp[tmp.length - 1].split("_");
        color = tmp[0];
        number = Integer.parseInt(tmp[1]);
        immagine = new ImageIcon(path);
    }

    public String getColor() {
        return color;
    }

    public int getNumber() {
        return number;
    }

    public ImageIcon getImmagine() {
        return immagine;
    }
}
