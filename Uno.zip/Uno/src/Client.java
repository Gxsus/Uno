import java.io.*;
import java.net.Socket;

public class Client {
    private Socket serverSocket;
    private BufferedReader input;
    private PrintWriter output;

    public Client(String serverAddress, int serverPort) {
        try {
            // Connessione al server
            serverSocket = new Socket(serverAddress, serverPort);

            // Inizializzazione degli stream di input/output
            input = new BufferedReader(new InputStreamReader(serverSocket.getInputStream()));
            output = new PrintWriter(serverSocket.getOutputStream(), true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void inviaMessaggio(String messaggio) {
        output.println(messaggio);
    }

    public String riceviRisposta() {
        try {
            return input.readLine();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
