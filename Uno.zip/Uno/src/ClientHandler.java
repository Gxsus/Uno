import java.io.*;
import java.net.Socket;

public class ClientHandler extends Thread {
    private Socket clientSocket;
    private BufferedReader input;
    private PrintWriter output;


    public ClientHandler(Socket clientSocket) {
        this.clientSocket = clientSocket;
        start();
    }

    @Override
    public void run() {
        try {
            input = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            output = new PrintWriter(clientSocket.getOutputStream(), true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String riceviRisposta() {
        String messaggio;
        try {
            messaggio = input.readLine();
        } catch (IOException e) {
            System.out.println(e.getMessage());
            return null;
        }
        System.out.println("Messaggio ricevuto dal client: " + messaggio);
        return messaggio;
    }

    public void mandaRisposta(String message) {
        output.println(message);
    }
    public void mandaRisposta(int message) {
        output.println(message);
    }

    public void mandaRisposta(Carta message) {
        output.println(message);
    }
}
