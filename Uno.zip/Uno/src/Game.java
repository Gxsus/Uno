import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.LinkedList;

public class Game extends Thread{
    private Mazzo mazzo;
    private boolean giro; // true in senso orario, false in senso antiorario
    private int turnoGiocatore; //salvo il numero del giocatore a cui tocca
    private Carta ultimaCarta;
    private LinkedList<ClientHandler> giocatori;
    public Game(LinkedList<ClientHandler> giocatori){
        mazzo = new Mazzo();
        turnoGiocatore = 0;
        giro = true;
        this.giocatori = giocatori;
        ultimaCarta = mazzo.pesca();
        start();
    }

    @Override
    public void run() {
        ClientHandler giocatore; // Il giocatore a cui tocca giocare
        Carta c; // Nel caso in cui il giocatore dovesse pescare una carta
        String []carta;
        while(true){
            giocatore = giocatori.get(turnoGiocatore);
            String scelta = giocatore.riceviRisposta();
            // Il giocatore ha scelto di pescare
            if(scelta.equals("p")) {
                c = mazzo.pesca();
                giocatore.mandaRisposta(c);
                continue;
            }
            // Il giocatore ha mandato una carta
            if(scelta.contains("c")) {
                carta = scelta.split("-");
                // Se abbiamo sicuramente un numero non controllo le possibilità
                if(carta[2].equals(Integer.toString(ultimaCarta.getNumber()))){
                    ultimaCarta = new Carta("C:\\Users\\39347\\Desktop\\Intellij\\Uno\\src\\PNGs\\large\\" + carta[1] + "_" + carta[2] + "_large.png");
                    incrementaTurno();
                }
                // Se abbiamo il colore uguale dovrò controllare le varie opzioni, cioè se è un numero oppure una carta speciale
                if(carta[1].equals(ultimaCarta.getColor())) {
                    try{
                        Integer.parseInt(carta[2]);
                        ultimaCarta = new Carta("C:\\Users\\39347\\Desktop\\Intellij\\Uno\\src\\PNGs\\large\\" + carta[1] + "_" + carta[2] + "_large.png");
                        incrementaTurno();
                    }catch(Exception ignored){
                        if(carta[2].equals("picker")) picker();
                        if(carta[2].equals("reverse")) reverse();
                        if(carta[2].equals("skip")) skip();
                    }
                }
                if(carta[1].equals("wild")&&carta[2].equals("colora")) {
                    ultimaCarta = new Carta("C:\\Users\\39347\\Desktop\\Intellij\\Uno\\src\\PNGs\\large\\" + carta[1] + "_" + carta[2] + "_large.png");
                    incrementaTurno();
                }
            }

        }
    }
    private void picker() {
        incrementaTurno();
        ClientHandler giocatore = giocatori.get(turnoGiocatore);
        Carta c = mazzo.pesca();
        giocatore.mandaRisposta(c);
        c = mazzo.pesca();
        giocatore.mandaRisposta(c);
    }
    private void skip() {
        incrementaTurno();
        incrementaTurno();
    }
    private void reverse() {
        giro = !giro;
    }
    private void incrementaTurno(){
        if(giro) turnoGiocatore++;
        else turnoGiocatore--;
        if(turnoGiocatore>=4) turnoGiocatore = 0;
        if(turnoGiocatore<0) turnoGiocatore = 3;
    }
}
