import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Index extends JFrame{
    private JPanel mainPanel;
    private JLabel giocatori;

    public Index() throws InterruptedException {
        Client c = new Client("localhost", 4000);
        setContentPane(mainPanel);
        setTitle("Benvenuto");
        setSize(600, 400);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);
        Client utente = new Client("localhost", 4000);
        while(true) {
            c.inviaMessaggio("g");
            String risposta = c.riceviRisposta();
            if(giocatori.equals("4")) {
                //new Uno(c);
                return;
            }
            giocatori.setText(risposta);
            Thread.sleep(1000);
        }
    }
}
