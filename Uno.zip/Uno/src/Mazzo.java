import java.util.LinkedList;
import java.util.Collections;
public class Mazzo {
    private LinkedList<Carta> carte;
    private Carta dorso;
    public Mazzo(){
        //link carte: https://opengameart.org/content/uno-playing-cards-2d
        String path = "C:\\Users\\39347\\Desktop\\Intellij\\Uno\\src\\PNGs\\large\\";
        creaMazzo(path);
        //salviamo il dorso delle carte
        dorso = new Carta(path + "card_back_large.png");
    }

    public Carta getDorso() {
        return dorso;
    }
    public void mischia(){
        Collections.shuffle(carte);
    }
    public Carta pesca(){
        return carte.removeFirst();
    }
    public void creaMazzo(String path){
        String []colors = {"blue", "green", "red", "yellow"};
        String []specials = {"skip", "reverse", "picker"};
        //aggiungiamo tutte le carte colorate
        for(String color:colors)
            for(String special:specials)
                carte.add(new Carta(path + color + '_' + special + "_large.png"));
        for(String color:colors)
            for(int i = 0; i < 10; i++)
                carte.add(new Carta(path + color + '_' + i + "_large.png"));
        //aggiungiamo le carte speciali
        for(int i = 0; i < 4; i++) {
            carte.add(new Carta(path + "wild_colora_changer_large.png"));
            carte.add(new Carta(path + "wild_pick_four_large.png"));
        }
    }
}
