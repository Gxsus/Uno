import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;

public class Server extends Thread {
    private ServerSocket serverSocket;
    private LinkedList<ClientHandler> giocatori = new LinkedList<>();

    public Server(int port) throws IOException {
        serverSocket = new ServerSocket(port);
    }

    @Override
    public void run() {
        String richiesta;
        try {
            while (true) {
                Socket clientSocket = serverSocket.accept();
                // Crea un nuovo thread per gestire la connessione del client
                giocatori.add(new ClientHandler(clientSocket));
                // Quando ci sono abbastanza giocatori il gioco inizia
                if(giocatori.size()==4) {
                    new Game(giocatori);
                    giocatori = new LinkedList<>();
                }
                for(ClientHandler giocatore:giocatori) {
                    richiesta = giocatore.riceviRisposta();
                    if (richiesta!=null && richiesta.contains("g"))
                        giocatore.mandaRisposta(giocatori.size());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        int port = 4000;
        try {
            Server server = new Server(port);
            server.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
