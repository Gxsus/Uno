import javax.swing.*;

public class Uno {
    private JLabel nCarte1;
    private JLabel nCarte3;
    private JLabel nCarte2;
    private JLabel nCarte4;
    private JButton prossimaManoButton;
    private JButton manoPrecedenteButton;
    private JLabel carta1;
    private JLabel carta2;
    private JLabel carta3;
    private JLabel carta4;
}
